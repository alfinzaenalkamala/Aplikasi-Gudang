package news.nec.example.com.gudangtoko;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.regex.Pattern;

import static android.view.View.GONE;

public class RegisActivity extends AppCompatActivity {

    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    "(?=.*[0-9])" +         //at least 1 digit
                    //"(?=.*[a-z])" +         //at least 1 lower case letter
                    //"(?=.*[A-Z])" +         //at least 1 upper case letter
                    "(?=.*[a-zA-Z])" +      //any letter
                    //"(?=.*[@#$%^&+=])" +    //at least 1 special character
                    "(?=\\S+$)" +           //no white spaces
                    ".{4,}" +               //at least 4 characters
                    "$");

    private static final int CODE_GET_REQUEST = 1024;
    private static final int CODE_POST_REQUEST = 1025;

    EditText ituserpass,itname,itemail;
    Button btnregis;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regis);

       
        ituserpass = (EditText) findViewById(R.id.user_pass);
        itname = (EditText) findViewById(R.id.name);
        itemail = (EditText) findViewById(R.id.email);

        progressBar = findViewById(R.id.progressBar);

        btnregis = (Button) findViewById(R.id.btnregis);
        btnregis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createRegis();
            }
        });
    }

    private void createRegis() {
        String name = itname.getText().toString().trim();
        String email = itemail.getText().toString().trim();
        String userpass = ituserpass.getText().toString().trim();


        if (TextUtils.isEmpty(name)) {
            itname.setError("masukkan nama");
            itname.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(email)) {
            itemail.setError("masukkan email");
            itemail.requestFocus();
            return;
        }   if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            itemail.setError("alamat email tidak falid");
            itemail.requestFocus();
            return;
  // regular expression
        }

       
        if (TextUtils.isEmpty(userpass)) {
            ituserpass.setError("masukkan password");
            ituserpass.requestFocus();
            return;
        }




        HashMap<String, String> params = new HashMap<>();
        params.put("pass", userpass);
        params.put("name", name);
        params.put("email", email);


        PerformNetworkRequest request = new PerformNetworkRequest(Api.URL_REGIS_HERO,params,CODE_POST_REQUEST);
        request.execute();

    }

    public class PerformNetworkRequest extends AsyncTask<Void, Void, String> {
        String url;
        HashMap<String, String> params;
        int requestCode;

        PerformNetworkRequest(String url, HashMap<String, String> params, int requestCode) {
            this.url = url;
            this.params = params;
            this.requestCode = requestCode;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressBar.setVisibility(GONE);
            try {
                JSONObject object = new JSONObject(s);
                if (!object.getBoolean("error")) {
                    Toast.makeText(getApplicationContext(), object.getString("message"), Toast.LENGTH_SHORT).show();
                    Intent inn = new Intent(RegisActivity.this,LoginActivity.class);
                    startActivity(inn);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(Void... voids) {
            RequestHandler requestHandler = new RequestHandler();

            if (requestCode == CODE_POST_REQUEST)
                return requestHandler.sendPostRequest(url, params);


            if (requestCode == CODE_GET_REQUEST)
                return requestHandler.sendGetRequest(url);
            return null;
        }


    }
}
