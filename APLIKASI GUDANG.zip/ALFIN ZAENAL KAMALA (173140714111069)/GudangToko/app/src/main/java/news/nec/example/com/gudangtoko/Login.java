package news.nec.example.com.gudangtoko;

public class Login {

    private String email,pass;

    public Login(String email, String pass) {
        this.email = email;
        this.pass = pass;
    }

    public String getEmail() {
        return email;
    }

    public String getPass() {
        return pass;
    }
}
